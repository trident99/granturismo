/*
**	This file is part of the GT Core Library.
**  It is based on a merger of QT along with development of new classes.
**  License information is in the License.h file
**	This software was merged and developed by:
**	
**  Anthony Daniels
**	QT by Nokia
**
**  GT is free software: you can redistribute it and/or modify
**  it under the terms of the GNU Lesser General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  The United States of America Department of Defense has unlimited 
**	usage, redistribution, and modification rights to GT.
**
**  GT is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU Lesser General Public License for more details.
**
**  You should have received a copy of the GNU Lesser General Public License
**  along with GT.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GT_GRID_SELECTION_H
#define GT_GRID_SELECTION_H

#include "..\GtGuiLibRefs.h"
#include <modGtGraphic.h>
#include <modGtGeometry.h>

using namespace HTL;
using namespace GT::GtCore;

namespace GT
{
	namespace GtGui
	{
		class GtGridCell;
		class GtGridView;
		typedef StlVector<GtGridCell*, HtlUnknownType> GtGridIndexList;
		typedef StlVector<GtGridCell*, HtlUnknownType>::StlIterator GtGridIndexIter;

class HTL_DLLAPI GtGridSelection : public GtObject
		{
		public:
			//!Parent set constructor
			GtGridSelection(GtObject* ptrParent = NULL);
			//!Virtual destructor
			virtual ~GtGridSelection(void);
			//!Copy Constructor
			GtGridSelection(const GtGridSelection& rhs);
			//!Assignment Operator
			GtGridSelection & operator= ( GtGridSelection & rhs);
			//MEMBER VARIABLES////////////////////////
			//!The pointer to the grid view
			GTOBJECT_MEMVAR_BYVAL(public, GtGridView*, ptrGrid);
			//!Pointer to the parent object
			GTOBJECT_MEMVAR_BYVAL(public, GtGridCell*, ptrTopLeft);
			//!Pointer to the parent object
			GTOBJECT_MEMVAR_BYVAL(public, GtGridCell*, ptrBottomRight);

			//SIGNALS/////////////////////////////////
		public:
			HtlSignal00 SelectionAdd;
			HtlSignal00 SelectionRemove;
			//MEMBER FUNCTIONS////////////////////////
			//!Get of number of cells
			long CountCells(void);
			long CountRows(void);
			long CountColumns(void);
			void GetRange(int & lRow,int & hRow, int & lCol, int & hCol);
			//!Get a cell by its index in the collection
			GtGridCell* GetCell(int index);
			//!Get a cell by its row and column number
			GtGridCell* GetCell(int row, int col);

			//ADDING REMOVAL SORTING METHODS/////////////////////

			//!Add the index to the selection
			void AddSelIndex(GtGridCell * ptrIndex);
			//!Remove the index from the selection
			void RemoveSelIndex(GtGridCell * ptrIndex);
			//!Add a range of cells
			void AddRangeCells(int lRow,int hRow, int lCol, int hCol);
			//!Gets the selected range based on the top left and bottom right
			void GetSelectedRange(void);
			//!Sorts the selection in ascending order (col, row, page order)
			void SortSelection(void);
			//!Clears the selection
			void ClearSelection(void);






		protected:
			//!pointer to the column
			StlVector<GtGridCell*,HTL_BASE_PTR> m_arrCells;
			//!Local copy of range extents
			int m_intLRow;
			int m_intHRow;
			int m_intLCol;
			int m_intHCol;
		};//end GtGridRow class definition

	}//end namespace GtCore
}//end namespace GT
#endif //GT_OBJECT_H