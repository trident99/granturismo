

#ifndef GT_IMAGE_SCALE_H
#define GT_IMAGE_SCALE_H

//Variant A
// Smooth bitmap resize
//
// Ivaylo Byalkov, November 16, 2000
//
 
#include <math.h>
#include <Windows.h>
#include "..\GtCoreLibRefs.h"

///////////////////////////////////////////////////////////
 
// helper function prototypes
static BITMAPINFO *PrepareRGBBitmapInfo(WORD wWidth, WORD wHeight);
static void ShrinkData(BYTE *pInBuff, WORD wWidth, WORD wHeight,
				BYTE *pOutBuff, WORD wNewWidth, WORD wNewHeight);
static void EnlargeData(BYTE *pInBuff, WORD wWidth, WORD wHeight,
				 BYTE *pOutBuff, WORD wNewWidth, WORD wNewHeight);
 
///////////////////////////////////////////////////////////
// Main resize function
 
HBITMAP ScaleBitmap(HBITMAP hBmp, WORD wNewWidth, WORD wNewHeight);

///////////////////////////////////////////////////////////
 //////////////////////////////////////////////////
 
static float *CreateCoeff(int nLen, int nNewLen, BOOL bShrink);

///////////////////////////////////////////////////////////
 
#define F_DELTA		0.0001f
 




//Variant B
// Functions for smooth bitmap resize
//
// Improvement: float calculations changed to int.
//
// Ivaylo Byalkov, January 24, 2000
// e-mail: ivob@i-n.net
//

 
///////////////////////////////////////////////////////////
 
// helper function prototypes
static BITMAPINFO *PrepareRGBBitmapInfo(WORD wWidth, 
                                        WORD wHeight);
 
static void ShrinkDataInt(BYTE *pInBuff, 
                          WORD wWidth, 
                          WORD wHeight,
                          BYTE *pOutBuff, 
                          WORD wNewWidth, 
                          WORD wNewHeight);
 
static void EnlargeDataInt(BYTE *pInBuff, 
                           WORD wWidth, 
                           WORD wHeight,
                           BYTE *pOutBuff, 
                           WORD wNewWidth, 
                           WORD wNewHeight);
 
///////////////////////////////////////////////////////////
// Main resize function

HBITMAP ScaleBitmapInt(HBITMAP hBmp,
	WORD wNewWidth,
	WORD wNewHeight);

 
///////////////////////////////////////////////////////////

BITMAPINFO *PrepareRGBBitmapInfo(WORD wWidth, WORD wHeight);

 
///////////////////////////////////////////////////////////
 
static int *CreateCoeffInt(int nLen, int nNewLen, BOOL bShrink);

///////////////////////////////////////////////////////////
 

#endif