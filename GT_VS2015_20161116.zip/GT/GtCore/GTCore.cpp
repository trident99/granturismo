// This is the main DLL file.

#include "GTCore.h"

