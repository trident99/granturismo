#include "gtgui.h"

GtGui::GtGui()
{

}

GtGui::~GtGui()
{

}
