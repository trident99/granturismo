// This is the main DLL file.
#include "GtChartLibRefs.h"
#include "GTChart.h"
