#ifndef GTGUI_H
#define GTGUI_H

class GTGUI_EXPORT GtGui
{
public:
	GtGui();
	~GtGui();

private:

};

#endif // GTGUI_H
