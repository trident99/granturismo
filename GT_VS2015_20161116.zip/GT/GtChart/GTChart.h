// GTChart.h

#pragma once
namespace GT
{
	namespace GtChart
	{
		//public ref class Class1
		//{
		//	// TODO: Add your methods for this class here.
		//};
	}
}
