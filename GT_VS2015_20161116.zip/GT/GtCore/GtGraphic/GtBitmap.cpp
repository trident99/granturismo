/*
**	This file is part of the GT Core Library.
**  It is based on a merger of QT along with development of new classes.
**  License information is in the License.h file
**	This software was merged and developed by:
**	
**  Anthony Daniels
**	QT by Nokia
**
**  GT is free software: you can redistribute it and/or modify
**  it under the terms of the GNU Lesser General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  The United States of America Department of Defense has unlimited 
**	usage, redistribution, and modification rights to GT.
**
**  GT is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU Lesser General Public License for more details.
**
**  You should have received a copy of the GNU Lesser General Public License
**  along with GT.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
** GIVE CREDIT WHERE CREDIT IS DUE
** GtBitmap is a slimmed down version of the 
** CBitmapEx - Free C++ Bitmap Manipulation Class
** written by:
** darkoman 
** Software Developer (Senior) Elektromehanika d.o.o. Nis 
** Serbia Serbia 
** Thank you very much for the code contribution
*/

#pragma once
#pragma warning(push)
#pragma warning (disable : 4005 ) /* macro redefinition */
#define HTL_DLLEXPORT
#pragma warning(pop)

#include ".\GtBitmap.h"
#include ".\GtImageScale.h"

#include <io.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <math.h>
using namespace HTL;

namespace GT
{
	namespace GtCore
	{

		//!Default Constructor
		GtBitmap::GtBitmap()
		{
			m_pFile = NULL;
			m_hBitmap = NULL;
			m_hScaled = NULL;
			m_intResourceID = 0;
			m_objFrame.Zero();
		};

		GtBitmap::GtBitmap(long width, long height)
		{
		};

		GtBitmap::GtBitmap(const GtBitmap & rhs)
		{

		};
		//!Destructor
		GtBitmap::~GtBitmap()
		{
			//do nothing
			if(m_hBitmap)
				DeleteObject(m_hBitmap);
		};

		//operator overloads
		GtBitmap & GtBitmap::operator= (GtBitmap & rhs)
		{
			if(&rhs != this)
			{
				m_hBitmap = rhs.m_hBitmap;
				m_hScaled = rhs.m_hScaled;
				m_strPath = rhs.m_strPath;
				m_bmap = rhs.m_bmap;
				m_pFile = rhs.m_pFile;
				m_intResourceID = rhs.m_intResourceID;
				m_objFrame = rhs.m_objFrame;
			}
			return (*this);
		};
		bool GtBitmap::IsLoaded(void)
		{
			if (m_hBitmap)
			{
				return true;
			}else {
				return false;
			}
		}

		void GtBitmap::Reset()
		{
			if (m_pFile)
			{
				fclose(m_pFile);
				delete m_pFile;
				m_pFile = NULL;
			}
			if (m_hBitmap)
			{
				DeleteObject(m_hBitmap);
			}
			if (m_hScaled)
			{
				DeleteObject(m_hScaled);
			}
		};


		void GtBitmap::Load()
		{
			this->Reset();

			LPTSTR szFileName;
			szFileName = (LPTSTR)m_strPath.c_str();
			// Check for valid .BMP file path
			if (m_strPath.size() > 0)
			{
				// Open .BMP file
				m_pFile = fopen(m_strPath.c_str(), ("rb"));
				if (m_pFile != NULL)
				{

					m_hBitmap = (HBITMAP)LoadImage(NULL, szFileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

					GetObject(m_hBitmap, sizeof(m_bmap), &m_bmap);
					m_objFrame.xMax = m_bmap.bmWidth;
					m_objFrame.yMax = m_bmap.bmHeight;

				}	
			}
			else if (m_intResourceID != 0)
			{
				m_hBitmap = (HBITMAP)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(m_intResourceID), IMAGE_BITMAP, 0, 0, NULL);
				GetObject(m_hBitmap, sizeof(m_bmap), &m_bmap);
				m_objFrame.xMax = m_bmap.bmWidth;
				m_objFrame.yMax = m_bmap.bmHeight;

			}


		}

		void GtBitmap::ScaleBitmap(GtRectI & target)
		{
			m_objFrame = target;
			if (m_hBitmap)
			{
				m_hScaled = ScaleBitmapInt(m_hBitmap, m_objFrame.Width(), m_objFrame.Height());
			}
		};
		void GtBitmap::DrawBitmap(HDC & devcontext)
		{
			if (m_hScaled)
			{	
				HDC hdcMem = CreateCompatibleDC(devcontext);
				HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, m_hScaled);
				DWORD lastError = GetLastError();
				
				bool success = BitBlt(devcontext, m_objFrame.GetLeft(), m_objFrame.GetTop(),
					m_objFrame.Width(), m_objFrame.Height(), hdcMem, 0, 0, SRCCOPY);
				SelectObject(hdcMem, m_hScaled);
				DeleteDC(hdcMem);
			}
			else if (m_hBitmap)
			{
				HDC hdcMem = CreateCompatibleDC(devcontext);
				HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, m_hBitmap);
				DWORD lastError = GetLastError();

				bool success = BitBlt(devcontext, m_objFrame.GetLeft(), m_objFrame.GetTop(),
					m_objFrame.Width(), m_objFrame.Height(), hdcMem, 0, 0, SRCCOPY);
				SelectObject(hdcMem, m_hBitmap);
				DeleteDC(hdcMem);
			}

		};

	};//end namespace GtCore

};//end namespace GT







