/*
**	This file is part of the GT Core Library.
**  It is based on a merger of QT along with development of new classes.
**  License information is in the License.h file
**	This software was merged and developed by:
**	
**  Anthony Daniels
**	QT by Nokia
**
**  GT is free software: you can redistribute it and/or modify
**  it under the terms of the GNU Lesser General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  The United States of America Department of Defense has unlimited 
**	usage, redistribution, and modification rights to GT.
**
**  GT is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU Lesser General Public License for more details.
**
**  You should have received a copy of the GNU Lesser General Public License
**  along with GT.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
** GIVE CREDIT WHERE CREDIT IS DUE
** GtBitmap is a slimmed down version of the 
** CBitmapEx - Free C++ Bitmap Manipulation Class
** written by:
** darkoman 
** Software Developer (Senior) Elektromehanika d.o.o. Nis 
** Serbia Serbia 
** Thank you very much for the code contribution
*/

#ifndef GT_BITMAP_H
#define GT_BITMAP_H

#include <windows.h>
#include <gdiplus.h>
using namespace Gdiplus;

#include ".\GtColor.h"
#include "..\modGtGeometry.h"

namespace GT
{
	namespace GtCore
	{

#define _PI	3.1415926f											// Value of PI
#define _BITS_PER_PIXEL_32	32									// 32-bit color depth
#define _BITS_PER_PIXEL_24	24									// 24-bit color depth
#define _PIXEL	DWORD											// Pixel
#define _RGB(r,g,b)	(((r) << 16) | ((g) << 8) | (b))			// Convert to RGB
#define _GetRValue(c)	((BYTE)(((c) & 0x00FF0000) >> 16))		// Red color component
#define _GetGValue(c)	((BYTE)(((c) & 0x0000FF00) >> 8))		// Green color component
#define _GetBValue(c)	((BYTE)((c) & 0x000000FF))				// Blue color component


//DEFINES KEPT FOR FUTURE REFERENCE
//typedef long fixed;												// Our new fixed point type
//#define itofx(x) ((x) << 8)										// Integer to fixed point
//#define ftofx(x) (long)((x) * 256)								// Float to fixed point
//#define dtofx(x) (long)((x) * 256)								// Double to fixed point
//#define fxtoi(x) ((x) >> 8)										// Fixed point to integer
//#define fxtof(x) ((float) (x) / 256)							// Fixed point to float
//#define fxtod(x) ((double)(x) / 256)							// Fixed point to double
//#define Mulfx(x,y) (((x) * (y)) >> 8)							// Multiply a fixed by a fixed
//#define Divfx(x,y) (((x) << 8) / (y))							// Divide a fixed by a fixed

		//!This class is a basic container for a bitmap image. 
		//It is based on the CBitmapEx class developed by darkoman of the Code Project (www.codeproject.com)
		class HTL_DLLAPI GtBitmap
		{
		public:
			//!Default Constructor
			GtBitmap();
			GtBitmap(long width, long height);
			//!Copy Constructor
			GtBitmap(const GtBitmap & rhs);
			//!Destructor
			~GtBitmap();

			//Operator overloads
			GtBitmap & operator= (GtBitmap & rhs);
		public:
			HBITMAP GetBmpPtr(void) { return m_hBitmap; };
			bool IsLoaded(void);
			void Load();
			void Reset();
			void ScaleBitmap(GtRectI & target);
			void DrawBitmap(HDC & devcontext);
		public:
			// Private members
			HBITMAP m_hBitmap;
			HBITMAP m_hScaled;
			BITMAP m_bmap;
			string m_strPath;
			int m_intResourceID;
			FILE* m_pFile;
			GtRectI m_objFrame;




		};//end GtEvent

	};//end namespace GtCore

};//end namespace GT

#endif//GT_PIXMAP_H